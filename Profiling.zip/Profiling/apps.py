from django.apps import AppConfig


class ProfilingConfig(AppConfig):
    name = 'Profiling'
